package com.example.connectapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;

public class AddEmployeeActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private EditText editTextName;
    private EditText editTextID;
    private EditText editTextPosition;
    private EditText editTextDOB;
    private EditText editTextMobileNo;
    private Button buttonSave;
    private Button buttonChooseImage;
    private ImageView imageViewProfile;
    private Uri imageUri;
    private EmployeeDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);

        editTextName = findViewById(R.id.edit_text_name);
        editTextID = findViewById(R.id.edit_text_id);
        editTextPosition = findViewById(R.id.edit_text_position);
        editTextDOB = findViewById(R.id.edit_text_dob);
        editTextMobileNo = findViewById(R.id.edit_text_mobile_no);
        buttonSave = findViewById(R.id.button_save);
        buttonChooseImage = findViewById(R.id.button_choose_image);
        imageViewProfile = findViewById(R.id.image_view_profile);
        dbHelper = new EmployeeDatabaseHelper(this);

        buttonChooseImage.setOnClickListener(v -> openImageChooser());

        buttonSave.setOnClickListener(v -> saveEmployeeInfo());
    }

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imageViewProfile.setImageBitmap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void saveEmployeeInfo() {
        String name = editTextName.getText().toString().trim();
        String id = editTextID.getText().toString().trim();
        String position = editTextPosition.getText().toString().trim();
        String dob = editTextDOB.getText().toString().trim();
        String mobileNo = editTextMobileNo.getText().toString().trim();
        String imageUriString = (imageUri != null) ? imageUri.toString() : null;

        if (name.isEmpty() || id.isEmpty() || position.isEmpty() || dob.isEmpty() || mobileNo.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EmployeeDatabaseHelper.COLUMN_NAME, name);
        values.put(EmployeeDatabaseHelper.COLUMN_ID, id);
        values.put(EmployeeDatabaseHelper.COLUMN_POSITION, position);
        values.put(EmployeeDatabaseHelper.COLUMN_DOB, dob);
        values.put(EmployeeDatabaseHelper.COLUMN_MOBILE_NO, mobileNo);
        values.put(EmployeeDatabaseHelper.COLUMN_IMAGE_URI, imageUriString);

        long newRowId = db.insert(EmployeeDatabaseHelper.EMPLOYEE_TABLE_NAME, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Employee added successfully!", Toast.LENGTH_SHORT).show();
            // Redirect to attendance entry page or activity
            Intent attendanceIntent = new Intent(AddEmployeeActivity.this, AttendanceActivity.class);
            attendanceIntent.putExtra("employee_id", id);
            startActivity(attendanceIntent);
            finish();
        } else {
            Toast.makeText(this, "Error adding employee. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
