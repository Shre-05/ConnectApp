package com.example.connectapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HolidayAdapter extends RecyclerView.Adapter<HolidayAdapter.HolidayViewHolder> {
    private Context context;
    private List<Holiday> holidays;

    public HolidayAdapter(Context context, List<Holiday> holidays) {
        this.context = context;
        this.holidays = holidays;
    }

    @NonNull
    @Override
    public HolidayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_holiday, parent, false);
        return new HolidayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolidayViewHolder holder, int position) {
        Holiday holiday = holidays.get(position);
        holder.holidayImage.setImageResource(holiday.getImageResourceId());
    }

    @Override
    public int getItemCount() {
        return holidays.size();
    }

    public static class HolidayViewHolder extends RecyclerView.ViewHolder {
        ImageView holidayImage;

        public HolidayViewHolder(@NonNull View itemView) {
            super(itemView);
            holidayImage = itemView.findViewById(R.id.holiday_image);
        }
    }
}
