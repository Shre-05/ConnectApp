package com.example.connectapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerViewEmployeeDetails;
    private EmployeeProfileAdapter employeeAdapter;
    private List<EmployeeProfileAdapter.Employee> employeeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        recyclerViewEmployeeDetails = findViewById(R.id.recycler_view_employee_details);

        employeeList = new ArrayList<>(Arrays.asList(
                new EmployeeProfileAdapter.Employee("Nia", "App developer", R.drawable.profile_a, true),
                new EmployeeProfileAdapter.Employee("Moana", "Q&A tester", R.drawable.profile_b, false),
                new EmployeeProfileAdapter.Employee("Nick", "SDE-2", R.drawable.profile_c, true),
                new EmployeeProfileAdapter.Employee("Sam", "Cloud architect", R.drawable.profile_d, false)
        ));


        employeeAdapter = new EmployeeProfileAdapter(this, employeeList);
        recyclerViewEmployeeDetails.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewEmployeeDetails.setAdapter(employeeAdapter);


        RecyclerView recyclerViewUpcomingHolidays = findViewById(R.id.recycler_view_upcoming_holidays);
        List<Holiday> holidayList = Arrays.asList(
                new Holiday(R.drawable.new_year),
                new Holiday(R.drawable.diwali),
                new Holiday(R.drawable.independence_day),
                new Holiday(R.drawable.merrycristmas),
                new Holiday(R.drawable.pongal),
                new Holiday(R.drawable.ganeshchaturthi),
                new Holiday(R.drawable.holi),
                new Holiday(R.drawable.makar_sankrant),
                new Holiday(R.drawable.palkhi),
                new Holiday(R.drawable.teej),
                new Holiday(R.drawable.rakhi)
        );
        com.example.connectapp.HolidayAdapter holidayAdapter = new com.example.connectapp.HolidayAdapter(this, holidayList);
        recyclerViewUpcomingHolidays.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerViewUpcomingHolidays.setAdapter(holidayAdapter);


        Button buttonAddEmployee = findViewById(R.id.button_add_employee);
        buttonAddEmployee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addEmployeeIntent = new Intent(HomeActivity.this, com.example.connectapp.AddEmployeeActivity.class);
                startActivity(addEmployeeIntent);
            }
        });


        Button buttonMarkAttendance = findViewById(R.id.button_attendance);
        buttonMarkAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent markAttendanceIntent = new Intent(HomeActivity.this, com.example.connectapp.AttendanceActivity.class);
                startActivity(markAttendanceIntent);
            }
        });

        Button buttonAssignTask = findViewById(R.id.button4);
        buttonAssignTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, com.example.connectapp.AssignTaskActivity.class);
                startActivity(intent);
            }
        });

    }


    @Override
    protected void onResume() {
        super.onResume();

    }
}
