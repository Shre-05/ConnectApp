package com.example.connectapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EmployeeProfileAdapter extends RecyclerView.Adapter<EmployeeProfileAdapter.EmployeeViewHolder> {

    private Context context;
    private List<Employee> employeeList;

    public EmployeeProfileAdapter(Context context, List<Employee> employeeList) {
        this.context = context;
        this.employeeList = employeeList;
    }

    @NonNull
    @Override
    public EmployeeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_employee_profile, parent, false);
        return new EmployeeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmployeeViewHolder holder, int position) {
        Employee employee = employeeList.get(position);
        holder.textViewName.setText(employee.getName());
        holder.textViewPosition.setText(employee.getPosition());
        holder.imageViewProfile.setImageResource(employee.getImageResource());


        holder.textViewAttendanceStatus.setText(employee.isPresent() ? "Present" : "Absent");
    }

    @Override
    public int getItemCount() {
        return employeeList.size();
    }

    public static class Employee {
        private String name;
        private String position;
        private int imageResource;
        private boolean isPresent;

        public Employee(String name, String position, int imageResource, boolean isPresent) {
            this.name = name;
            this.position = position;
            this.imageResource = imageResource;
            this.isPresent = isPresent;
        }

        public String getName() {
            return name;
        }

        public String getPosition() {
            return position;
        }

        public int getImageResource() {
            return imageResource;
        }

        public boolean isPresent() {
            return isPresent;
        }
    }

    public static class EmployeeViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewName;
        private TextView textViewPosition;
        private ImageView imageViewProfile;
        private TextView textViewAttendanceStatus;

        public EmployeeViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_name);
            textViewPosition = itemView.findViewById(R.id.text_view_position);
            imageViewProfile = itemView.findViewById(R.id.image_view_profile);
            textViewAttendanceStatus = itemView.findViewById(R.id.text_view_attendance_status);
        }
    }
}
