package com.example.connectapp.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.connectapp.DatabaseHelper;
import com.example.connectapp.R;

public class SignupActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button signupButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize views and database helper
        usernameEditText = findViewById(R.id.signupUsername);
        passwordEditText = findViewById(R.id.signupPassword);
        signupButton = findViewById(R.id.signupButton);
        databaseHelper = new DatabaseHelper(this);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Add user to the database
                if (databaseHelper.addUser(username, password)) {
                    Toast.makeText(SignupActivity.this, "Sign up successful!", Toast.LENGTH_SHORT).show();
                    // Go back to login page
                    Intent intent = new Intent(SignupActivity.this, com.example.connectapp.LoginActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(SignupActivity.this, "Sign up failed. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
