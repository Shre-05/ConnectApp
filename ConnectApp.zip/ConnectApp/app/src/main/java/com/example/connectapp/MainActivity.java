package com.example.connectapp;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.navigation.NavigationView;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        toolbar.setNavigationIcon(R.drawable.menu);




        RecyclerView recyclerViewEmployeeDetails = findViewById(R.id.recycler_view_employee_details);
        List<EmployeeProfileAdapter.Employee> employeeList = Arrays.asList(
                new EmployeeProfileAdapter.Employee("Nia", "App developer", R.drawable.profile_a, true),
                new EmployeeProfileAdapter.Employee("Moana", "Q&A tester", R.drawable.profile_b, false),
                new EmployeeProfileAdapter.Employee("Nick", "SDE-2", R.drawable.profile_c, true),
                new EmployeeProfileAdapter.Employee("Sam", "Cloud architect", R.drawable.profile_d, false)
        );
        EmployeeProfileAdapter employeeAdapter = new EmployeeProfileAdapter(this, employeeList);
        recyclerViewEmployeeDetails.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewEmployeeDetails.setAdapter(employeeAdapter);


        RecyclerView recyclerViewUpcomingHolidays = findViewById(R.id.recycler_view_upcoming_holidays);
        List<Holiday> holidayList = Arrays.asList(
                new Holiday(R.drawable.new_year),
                new Holiday(R.drawable.diwali),
                new Holiday(R.drawable.independence_day),
                new Holiday(R.drawable.merrycristmas),
                new Holiday(R.drawable.pongal),
                new Holiday(R.drawable.ganeshchaturthi),
                new Holiday(R.drawable.holi),
                new Holiday(R.drawable.makar_sankrant),
                new Holiday(R.drawable.palkhi),
                new Holiday(R.drawable.teej),
                new Holiday(R.drawable.rakhi)
        );
        HolidayAdapter holidayAdapter = new HolidayAdapter(this, holidayList);
        recyclerViewUpcomingHolidays.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerViewUpcomingHolidays.setAdapter(holidayAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            drawerLayout.openDrawer(GravityCompat.START);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
