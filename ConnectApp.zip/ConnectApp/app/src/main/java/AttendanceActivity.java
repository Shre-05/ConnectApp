package com.example.connectapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AttendanceActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextId;
    private CheckBox checkBoxPresent;
    private CheckBox checkBoxAbsent;
    private Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);


        editTextName = findViewById(R.id.edit_text_name);
        editTextId = findViewById(R.id.edit_text_id);
        checkBoxPresent = findViewById(R.id.check_box_present);
        checkBoxAbsent = findViewById(R.id.check_box_absent);
        buttonSave = findViewById(R.id.button_save);


        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAttendance();
            }
        });
    }

    private void saveAttendance() {

        String name = editTextName.getText().toString().trim();
        String id = editTextId.getText().toString().trim();
        boolean isPresent = checkBoxPresent.isChecked();
        boolean isAbsent = checkBoxAbsent.isChecked();


        if (name.isEmpty() || id.isEmpty()) {
            Toast.makeText(this, "Please enter both name and ID", Toast.LENGTH_SHORT).show();
            return;
        }


        if (isPresent && isAbsent) {
            Toast.makeText(this, "You cannot mark as both present and absent", Toast.LENGTH_SHORT).show();
            return;
        }


        Toast.makeText(this, "Attendance saved for " + name + " (ID: " + id + ")\nPresent: " + isPresent + "\nAbsent: " + isAbsent, Toast.LENGTH_LONG).show();

    }

     }

