package com.example.connectapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class AssignTaskActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EmployeeProfileAdapter adapter;
    private List<EmployeeProfileAdapter.Employee> employeeList;
    private Button buttonAssignTask;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_task);

        recyclerView = findViewById(R.id.recycler_view_assign_task);
        buttonAssignTask = findViewById(R.id.button_assign_task);


        employeeList = new ArrayList<>();
        employeeList.add(new EmployeeProfileAdapter.Employee("Nia", "App developer", R.drawable.profile_a, true));
        employeeList.add(new EmployeeProfileAdapter.Employee("Moana", "Q&A tester", R.drawable.profile_b, false));
        employeeList.add(new EmployeeProfileAdapter.Employee("Nick", "SDE-2", R.drawable.profile_c, false));
        employeeList.add(new EmployeeProfileAdapter.Employee("Sam", "Cloud Architect", R.drawable.profile_d, false));

        adapter = new EmployeeProfileAdapter(this, employeeList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        buttonAssignTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AssignTaskActivity.this, "Task assigned to selected employees!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
