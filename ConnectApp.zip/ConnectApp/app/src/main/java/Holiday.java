package com.example.connectapp;

public class Holiday {
    private int imageResourceId;

    public Holiday(int imageResourceId) {
        this.imageResourceId = imageResourceId;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }
}
