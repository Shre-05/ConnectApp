package com.example.connectapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EmployeeDatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "employee.db";
    public static final String EMPLOYEE_TABLE_NAME = "employee";
    public static final String ATTENDANCE_TABLE_NAME = "attendance";


    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_POSITION = "position";
    public static final String COLUMN_DOB = "dob";
    public static final String COLUMN_MOBILE_NO = "mobile_no";
    public static final String COLUMN_IMAGE_URI = "image_uri";


    public static final String COLUMN_ATTENDANCE_ID = "_id";
    public static final String COLUMN_EMPLOYEE_NAME = "employee_name";
    public static final String COLUMN_EMPLOYEE_ID = "employee_id";
    public static final String COLUMN_IS_PRESENT = "is_present";
    public static final String COLUMN_IS_ABSENT = "is_absent";


    private static final String SQL_CREATE_EMPLOYEE_ENTRIES =
            "CREATE TABLE " + EMPLOYEE_TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_NAME + " TEXT," +
                    COLUMN_POSITION + " TEXT," +
                    COLUMN_DOB + " TEXT," +
                    COLUMN_MOBILE_NO + " TEXT," +
                    COLUMN_IMAGE_URI + " TEXT)";


    private static final String SQL_CREATE_ATTENDANCE_ENTRIES =
            "CREATE TABLE " + ATTENDANCE_TABLE_NAME + " (" +
                    COLUMN_ATTENDANCE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_EMPLOYEE_NAME + " TEXT, " +
                    COLUMN_EMPLOYEE_ID + " TEXT, " +
                    COLUMN_IS_PRESENT + " INTEGER, " +
                    COLUMN_IS_ABSENT + " INTEGER)";

    public EmployeeDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_EMPLOYEE_ENTRIES);
        db.execSQL(SQL_CREATE_ATTENDANCE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + EMPLOYEE_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + ATTENDANCE_TABLE_NAME);

        onCreate(db);
    }
}
